import pygame
import numpy as np
import random
import math
import sys

# --- CONFIGURATION ---
WIDTH, HEIGHT = 720, 1280
FPS = 60
# Using absolute constants to avoid potential re-initialization issues
CENTER_X = WIDTH // 2
CENTER_Y = HEIGHT // 2
CENTER = np.array([CENTER_X, CENTER_Y], dtype=float)

# Mesmerizing Palette - Guaranteed coverage of all used keys
COLORS = {
    'cyan': (0, 255, 255),
    'violet': (190, 70, 255),
    'magenta': (255, 20, 147),
    'deep_blue': (15, 25, 70),
    'gold': (255, 215, 0),
    'white': (255, 255, 255),
    'black': (0, 0, 0),
    'nebula': (10, 10, 30)
}

def lerp_color(c1, c2, t):
    """Linearly interpolate between two RGB tuples safely."""
    t = max(0.0, min(1.0, float(t)))
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))

def get_bezier_point(p0, p1, p2, p3, t):
    """Calculate a point on a cubic Bézier curve using NumPy arrays."""
    t = float(t)
    inv_t = 1.0 - t
    return (inv_t**3 * p0 +
            3.0 * inv_t**2 * t * p1 +
            3.0 * inv_t * t**2 * p2 +
            t**3 * p3)

# --- CLASSES ---

class Particle:
    """Manages individual glowing particles with lifetime and fade-out."""
    def __init__(self, pos, vel, color, size, life, decay, is_sparkle=False):
        self.pos = np.array(pos, dtype=float)
        self.vel = np.array(vel, dtype=float)
        self.color = color
        self.size = float(size)
        self.max_life = float(life)
        self.life = float(life)
        self.decay = float(decay)
        self.is_sparkle = is_sparkle

    def update(self):
        self.pos += self.vel
        self.life -= self.decay
        if self.is_sparkle:
            self.vel *= 0.96 # Air resistance
        return self.life > 0

    def draw(self, surf):
        # Calculate alpha safely
        ratio = self.life / self.max_life
        alpha = int(max(0, min(255, ratio * 255)))

        # Draw concentric circles for a glow effect
        # We use a small surface for alpha blending
        s_int = int(max(1, self.size * 2))
        p_surf = pygame.Surface((s_int * 2, s_int * 2), pygame.SRCALPHA)

        # Outer glow
        pygame.draw.circle(p_surf, (*self.color, alpha // 2), (s_int, s_int), s_int)
        # Inner core
        pygame.draw.circle(p_surf, (*self.color, alpha), (s_int, s_int), s_int // 2)

        if self.is_sparkle and random.random() > 0.5:
            pygame.draw.circle(p_surf, (255, 255, 255, alpha), (s_int, s_int), max(1, s_int // 4))

        surf.blit(p_surf, (int(self.pos[0] - s_int), int(self.pos[1] - s_int)))

class Petal:
    """A procedural petal that grows from the center with glowing veins."""
    def __init__(self, angle, length, layer_idx):
        self.angle = float(angle)
        self.length = float(length)
        self.layer_idx = layer_idx

        self.growth = 0.0 # 0.0 to 1.0
        self.vein_growth = 0.0 # 0.0 to 1.0
        self.active = False
        self.finished = False

        # Visuals
        base_palette = [COLORS['magenta'], COLORS['violet'], COLORS['cyan']]
        self.color = base_palette[layer_idx % len(base_palette)]

        # Local Bézier points (petal points along positive X axis)
        self.p0 = np.array([0.0, 0.0], dtype=float)
        self.p3 = np.array([self.length, 0.0], dtype=float)

        # Width/Spread varies by layer for complexity
        spread = 25.0 + layer_idx * 15.0
        self.p1 = np.array([self.length * 0.3, -spread], dtype=float)
        self.p2 = np.array([self.length * 0.8, -spread * 1.5], dtype=float)

        # Define 3 internal veins
        self.veins = []
        for i in range(3):
            # Veins branch off at 20%, 45%, 70% of the petal length
            v_t = 0.2 + i * 0.25
            v_len = self.length * (0.3 + i * 0.15)
            v_angle = random.uniform(-0.4, 0.4)
            self.veins.append({'t': v_t, 'len': v_len, 'ang': v_angle})

    def update(self, delta):
        """Update growth state and return current tip position or 'FINISH' signal."""
        if not self.active or self.finished:
            return None

        # Phase 1: Grow main petal outline
        if self.growth < 1.0:
            self.growth += delta
            if self.growth >= 1.0:
                self.growth = 1.0

        # Phase 2: Grow veins (faster than outline)
        elif self.vein_growth < 1.0:
            self.vein_growth += delta * 2.5
            if self.vein_growth >= 1.0:
                self.vein_growth = 1.0
                self.finished = True
                return "FINISH_SIGNAL" # Use a clear string signal

        # Return tip position for sparkle trail (NumPy array)
        tip_local = get_bezier_point(self.p0, self.p1, self.p2, self.p3, self.growth)
        return self.get_world_pos(tip_local)

    def get_world_pos(self, local_p, rotation_offset=0.0):
        """Rotate and translate a local petal point to screen space."""
        total_ang = self.angle + rotation_offset
        cos_a = math.cos(total_ang)
        sin_a = math.sin(total_ang)

        # Standard 2D rotation matrix multiplication
        world_x = local_p[0] * cos_a - local_p[1] * sin_a
        world_y = local_p[0] * sin_a + local_p[1] * cos_a

        return np.array([CENTER_X + world_x, CENTER_Y + world_y])

    def draw(self, surf, rotation_offset=0.0, pulse=1.0):
        if not self.active and self.growth <= 0:
            return

        # Apply breathing pulse to the shape
        p3 = self.p3 * pulse
        p1 = self.p1 * pulse
        p2 = self.p2 * pulse

        # Generate points for the curve
        steps = 20
        t_range = np.linspace(0.0, self.growth, steps)

        # Top half
        pts_top = [self.get_world_pos(get_bezier_point(self.p0, p1, p2, p3, t), rotation_offset) for t in t_range]
        # Bottom half (mirrored Y)
        p1_mir = np.array([p1[0], -p1[1]])
        p2_mir = np.array([p2[0], -p2[1]])
        pts_bot = [self.get_world_pos(get_bezier_point(self.p0, p1_mir, p2_mir, p3, t), rotation_offset) for t in t_range]

        if len(pts_top) < 2: return

        # Draw glowing outline using multiple passes
        for width, alpha in [(8, 30), (4, 80), (2, 255)]:
            c = (*self.color, alpha)
            pygame.draw.lines(surf, c, False, pts_top, width)
            pygame.draw.lines(surf, c, False, pts_bot, width)

        # Draw veins if they have started growing
        if self.vein_growth > 0:
            for v in self.veins:
                # Start point on central axis
                start_dist = v['t'] * self.growth * self.length * pulse
                v_start = self.get_world_pos(np.array([start_dist, 0.0]), rotation_offset)

                # End point branched out
                v_cur_len = v['len'] * self.vein_growth * pulse
                # Branching angle relative to petal angle is handled by get_world_pos logic?
                # No, we need to calculate branch endpoint in local space first.
                v_end_local = np.array([
                    start_dist + math.cos(v['ang']) * v_cur_len,
                    math.sin(v['ang']) * v_cur_len
                ])
                v_end = self.get_world_pos(v_end_local, rotation_offset)

                pygame.draw.line(surf, (*COLORS['gold'], 150), v_start, v_end, 1)

class GalaxyCore:
    """The central pulsing energy core."""
    def __init__(self):
        self.angle = 0.0
        self.particles = []
        self.pulse = 1.0

    def update(self):
        self.angle += 0.03
        self.pulse = 1.0 + 0.15 * math.sin(pygame.time.get_ticks() * 0.004)

        # Emit particles in a spiral
        if random.random() < 0.6:
            a = self.angle + random.uniform(0, math.pi * 2)
            dist = random.uniform(2, 40)
            pos = CENTER + np.array([math.cos(a)*dist, math.sin(a)*dist])
            # Tangent velocity
            vel = np.array([-math.sin(a)*2, math.cos(a)*2])
            self.particles.append(Particle(pos, vel, COLORS['cyan'], random.uniform(1, 3), 1.0, 0.02))

        self.particles = [p for p in self.particles if p.update()]

    def draw(self, surf):
        # Core layers
        for i in range(5):
            r = (40 - i * 7) * self.pulse
            alpha = 30 + i * 40
            s = pygame.Surface((int(r*2), int(r*2)), pygame.SRCALPHA)
            pygame.draw.circle(s, (*COLORS['white'], alpha), (int(r), int(r)), int(r))
            surf.blit(s, (CENTER_X - r, CENTER_Y - r))

        for p in self.particles:
            p.draw(surf)

class AnimationApp:
    """Main application loop and state manager."""
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("COSMIC NEBULA FLOWER 🌸")
        self.clock = pygame.time.Clock()

        # Background Stars
        self.stars = []
        for _ in range(400):
            self.stars.append({
                'pos': (random.randint(0, WIDTH), random.randint(0, HEIGHT)),
                'size': random.uniform(0.5, 2.0),
                'speed': random.uniform(0.01, 0.05)
            })

        self.core = GalaxyCore()
        self.petals = []
        self.particles = []

        # Create 3 layers of petals
        # Inner: 8, Mid: 12, Outer: 16 -> 36 petals total
        counts = [8, 12, 16]
        lengths = [160, 260, 360]
        for layer_idx, count in enumerate(counts):
            for i in range(count):
                angle = (2 * math.pi / count) * i + (layer_idx * 0.4)
                self.petals.append(Petal(angle, lengths[layer_idx], layer_idx))

        self.state = "SEED" # SEED -> CORE -> BLOOMING -> COMPLETE
        self.timer = 0
        self.bloom_ptr = 0
        self.global_rot = 0.0

        # Radial background gradient
        self.bg_surf = pygame.Surface((WIDTH, HEIGHT))
        for r in range(int(HEIGHT * 0.7), 0, -15):
            t = 1.0 - (r / (HEIGHT * 0.7))
            color = lerp_color(COLORS['black'], COLORS['nebula'], t)
            pygame.draw.circle(self.bg_surf, color, (CENTER_X, CENTER_Y), r)

    def update(self):
        self.timer += 1

        # State transitions
        if self.state == "SEED":
            if self.timer > 100: self.state = "CORE"
        elif self.state == "CORE":
            self.core.update()
            if self.timer > 200: self.state = "BLOOMING"
        elif self.state == "BLOOMING":
            self.core.update()
            # Sequentially activate petals
            if self.bloom_ptr < len(self.petals):
                p = self.petals[self.bloom_ptr]
                p.active = True
                # Trigger next petal after some growth
                if p.growth > 0.4:
                    # Delay between petals based on layer
                    delay = 6 if p.layer_idx == 0 else (10 if p.layer_idx == 1 else 14)
                    if self.timer % delay == 0:
                        self.bloom_ptr += 1

            if all(p.finished for p in self.petals):
                self.state = "COMPLETE"

        elif self.state == "COMPLETE":
            self.core.update()
            self.global_rot += 0.003 # Slow cinematic rotation

        # Update petals and handle growth effects
        for p in self.petals:
            res = p.update(0.006) # Slow drawing speed for satisfaction

            if res is None:
                continue

            # Use explicit string check instead of NumPy array equality comparison
            if isinstance(res, str) and res == "FINISH_SIGNAL":
                # Big burst at tip
                tip_p = p.get_world_pos(p.p3, self.global_rot)
                for _ in range(20):
                    ang = random.uniform(0, math.pi * 2)
                    spd = random.uniform(1, 5)
                    self.particles.append(Particle(
                        tip_p, [math.cos(ang)*spd, math.sin(ang)*spd],
                        COLORS['gold'], random.uniform(2, 4), 1.5, 0.02, True
                    ))
            elif isinstance(res, np.ndarray):
                # Trail particle at current growth tip
                if random.random() > 0.6:
                    self.particles.append(Particle(
                        res, [random.uniform(-0.5, 0.5), random.uniform(-0.5, 0.5)],
                        p.color, random.uniform(1, 3), 1.0, 0.05, True
                    ))

        # Ambient cosmic dust
        if random.random() < 0.2:
            self.particles.append(Particle(
                [random.randint(0, WIDTH), random.randint(0, HEIGHT)],
                [random.uniform(-0.2, 0.2), random.uniform(-0.2, 0.2)],
                COLORS['violet'], random.uniform(0.5, 2.0), 3.0, 0.005
            ))

        self.particles = [p for p in self.particles if p.update()]

    def draw(self):
        # 1. Background
        self.screen.blit(self.bg_surf, (0, 0))

        # 2. Twinkling Stars
        for s in self.stars:
            twinkle = 128 + 127 * math.sin(self.timer * s['speed'])
            pygame.draw.circle(self.screen, (200, 200, 255, int(twinkle)), s['pos'], int(s['size']))

        # 3. Petals (Back to Front)
        pulse = 1.0 + 0.05 * math.sin(self.timer * 0.05) if self.state == "COMPLETE" else 1.0
        for layer in [2, 1, 0]:
            for p in self.petals:
                if p.layer_idx == layer:
                    p.draw(self.screen, self.global_rot, pulse)

        # 4. Core or Seed
        if self.state == "SEED":
            s_pulse = 1.0 + 0.3 * math.sin(self.timer * 0.1)
            pygame.draw.circle(self.screen, COLORS['white'], (CENTER_X, CENTER_Y), int(4 * s_pulse))
            # Glowing aura for seed
            s_aura = pygame.Surface((40, 40), pygame.SRCALPHA)
            pygame.draw.circle(s_aura, (*COLORS['gold'], 100), (20, 20), int(12 * s_pulse))
            self.screen.blit(s_aura, (CENTER_X - 20, CENTER_Y - 20))
        else:
            self.core.draw(self.screen)

        # 5. Particles
        for p in self.particles:
            p.draw(self.screen)

        pygame.display.flip()

    def run(self):
        running = True
        try:
            while running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            running = False

                self.update()
                self.draw()
                self.clock.tick(FPS)
        except Exception as e:
            print(f"CRITICAL ERROR: {e}")
            import traceback
            traceback.print_exc()
        finally:
            pygame.quit()
            sys.exit()

if __name__ == "__main__":
    app = AnimationApp()
    app.run()
