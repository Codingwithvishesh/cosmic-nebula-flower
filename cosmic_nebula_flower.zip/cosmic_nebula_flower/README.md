# COSMIC NEBULA FLOWER 🌸

A breathtaking, procedurally generated fantasy flower animation built with Python. Watch as a mysterious, glowing flower from another galaxy organically blooms from a tiny cosmic seed into a magnificent structure with rotating energy and magical light trails.

---

## ✨ Overview
The **Cosmic Nebula Flower** is not a static video or a pre-rendered image. It is a live mathematical simulation. Every petal, vein, and particle is calculated in real-time using Bézier curves and physics-based particle systems, ensuring a unique and fluid visual experience every time you run it.

---

## 🎨 Key Features
- **Organic Blooming**: 36 intricately layered petals that draw themselves using smooth mathematical easing.
- **Glowing Vein System**: Detailed internal structures that illuminate as the flower matures.
- **Galaxy Core**: A central rotating energy core with orbiting light particles and a pulsing aura.
- **Cinematic Effects**: Multi-layered glow outlines, ambient cosmic dust, and sparkling bursts upon completion.
- **Procedural Design**: Uses cubic Bézier curves for elegant, non-linear petal shapes.
- **Immersive Background**: A deep radial gradient starfield with twinkling distant stars.

---

## 📂 Project Structure
```text
cosmic_nebula_flower/
│
├── main.py        # The complete Python source code
└── README.md      # Documentation and setup guide (this file)
```

---

## 💻 System Requirements
- **Operating System**: Windows 10/11 (Recommended)
- **Python Version**: Python 3.14.7 or higher (Fully compatible)
- **Display**: Minimum 1280px vertical resolution (runs in 720x1280 portrait mode)

### Required Dependencies
1. **Pygame-ce**: A high-performance library for 2D graphics and animation.
2. **NumPy**: Used for high-speed mathematical array operations and Bézier calculations.

---

## 🚀 Installation & Setup

Follow these steps to get the animation running on your Windows machine:

### 1. Install Dependencies
Open your PowerShell or Command Prompt and run the following command:
```powershell
pip install pygame-ce numpy
```

### 2. Navigate to Project Folder
Use the `cd` command to enter the project directory:
```powershell
cd "C:\Users\IT Tech\OneDrive\Desktop\cosmic_nebula_flower"
```

### 3. Run the Animation
Launch the Python script:
```powershell
python main.py
```

---

## ⌨️ Controls
| Action | Keyboard Shortcut |
| :--- | :--- |
| **Exit Animation** | `ESC` Key |
| **Close Window** | Click the `X` button |

---

## 🛠️ Customization
You can easily modify the flower's appearance by opening `main.py` in any text editor:

- **Change Colors**: Locate the `COLORS` dictionary (Lines 16-25) to adjust the palette (Cyan, Violet, Gold, etc.).
- **Animation Speed**: In `AnimationApp.update()`, look for `p.update(0.006)`. Increasing this value will make the flower bloom faster.
- **Flower Complexity**: In `AnimationApp.__init__()`, you can modify the `counts` and `lengths` arrays to change how many petals appear in each layer.
- **Resolution**: Adjust `WIDTH` and `HEIGHT` at the top of the file.

---

## ❓ Troubleshooting
- **Missing Module Error**: If you see `ModuleNotFoundError`, ensure you ran the `pip install` command mentioned above.
- **Window Too Large**: If the window doesn't fit your screen, change `HEIGHT = 1280` to a smaller value like `900` in `main.py`.
- **Low Performance**: Ensure your laptop is plugged in or set to "High Performance" mode.

---

## 📜 Credits
- **Project**: Cosmic Nebula Flower
- **Engine**: Pygame-ce & NumPy
- **Algorithm**: Procedural Bézier Geometry

*Devloped By Codingwithvishesh*
